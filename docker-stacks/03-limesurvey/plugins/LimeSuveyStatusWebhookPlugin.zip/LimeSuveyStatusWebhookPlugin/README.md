# Webhook for LimeSurvey
This is a simple LimeSurvey Plugin that allows you to send a post request on survey completions.

This plugin is a fork of the uncontinued [zesthook](https://github.com/evently-nl/zesthook) and can easily be adapted to suit your own needs.


## Installation
Download the zip from the [releases](https://github.com/IrishWolf/limesurvey_webhook/releases) page and extract to your plugins folder.
That should be under `root/upload/plugins`.


## Usage
You are free to use/change/fork this code for your own products.
